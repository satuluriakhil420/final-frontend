package com.ngo.skyfoundation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkyfoundationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkyfoundationApplication.class, args);
	}

}
